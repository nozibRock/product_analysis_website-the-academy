import React from 'react';

const Privacy = () => {
    return (
        <div>
            
        </div>
    );
};

export default Privacy;