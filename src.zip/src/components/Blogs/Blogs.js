import React from 'react';

const Blogs = () => {
    return (
        <div>
            
        </div>
    );
};

export default Blogs;