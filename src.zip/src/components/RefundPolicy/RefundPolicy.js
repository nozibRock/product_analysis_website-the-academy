import React from 'react';

const RefundPolicy = () => {
    return (
        <div>
            
        </div>
    );
};

export default RefundPolicy;