import React from 'react';

const Terms = () => {
    return (
        <div>
            
        </div>
    );
};

export default Terms;